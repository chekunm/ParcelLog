from pathlib import Path
import datetime,json,os,re,signal,time,serial
p=Path(__file__).resolve().parent
state={'state':'waiting','pid':os.getpid(),'port':4524,'target_mcu_ms':312000,'commands':[]}; stop=False
def save():
 t=p/'collector.tmp';t.write_text(json.dumps(state,indent=2)+'\n');t.replace(p/'collector.json')
def sig(*a):
 global stop
 stop=True
signal.signal(signal.SIGTERM,sig);signal.signal(signal.SIGINT,sig);save();end=time.monotonic()+240
while not stop and time.monotonic()<end:
 try:c=serial.serial_for_url('rfc2217://localhost:4524',baudrate=115200,timeout=.1);break
 except (OSError,serial.SerialException):time.sleep(.2)
else:state['state']='connection_timeout';save();raise SystemExit(1)
state.update(state='recording',started=datetime.datetime.now().astimezone().isoformat());save();buf=b'';last=-1;sent=False;wall=time.monotonic();lastsave=wall
try:
 with c,(p/'uart.raw').open('wb') as out:
  while not stop and time.monotonic()-wall<900:
   chunk=c.read(c.in_waiting or 1)
   if chunk:
    out.write(chunk);out.flush();buf+=chunk
    while b'\n' in buf:
     line,buf=buf.split(b'\n',1);m=re.search(rb'tick \[(\d+) ms\]',line)
     if not m:continue
     now=int(m.group(1))
     if now<last:raise RuntimeError('MCU time regressed')
     last=now;state['last_tick_ms']=now
     if not sent and now>=305000:
      if c.write(b'stats\n')!=6:raise IOError('short write')
      state['commands'].append({'command':'stats','mcu_ms':now});sent=True
     if sent and now>=312000:state['state']='complete';break
    if state['state']=='complete':break
   if time.monotonic()-lastsave>10:save();lastsave=time.monotonic()
  if stop:state['state']='interrupted'
  elif state['state']!='complete':state['state']='wall_timeout'
except Exception as e:state.update(state='failed',error=repr(e))
finally:state['end']=datetime.datetime.now().astimezone().isoformat();save()
