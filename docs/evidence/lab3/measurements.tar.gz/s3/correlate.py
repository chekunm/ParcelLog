from pathlib import Path
import re,json,bisect,hashlib
wire=Path('uart.raw').read_text(errors='replace')
events=[{'seq':int(seq),'time_ms':int(ms),'event':name,'t_us':int(us)} for seq,ms,name,us in re.findall(r'seq=(\d+) time_ms=(\d+) event=(\w+) mode=\w+ t_us=(\d+)',wire)]
t=0;signals={'$':[],'&':[]};previous={}
for line in Path('s3.vcd').open():
 x=line.strip()
 if x.startswith('#'):t=int(x[1:])
 elif len(x)==2 and x[1] in signals and x[0] in '01':
  if x[0]=='1' and previous.get(x[1])!='1':signals[x[1]].append(t)
  previous[x[1]]=x[0]
pirs=signals['$']; responses=signals['&'];pairs=[]
for t in pirs:
 j=bisect.bisect_left(responses,t)
 candidates=[x for x in responses[j:] if x<=t+200_000_000][:8]
 matched=[]
 for pulse in candidates:
  matches=[e for e in events if e['event']=='nearby_motion' and abs(pulse/1e6-e['time_ms'])<=20]
  other=[e for e in events if e['event']!='nearby_motion' and abs(pulse/1e6-e['time_ms'])<=20]
  matched.extend((pulse,e,other) for e in matches)
 if len(matched)==1 and not matched[0][2]:
  pulse,e,_=matched[0];pairs.append({'pir_ns':t,'response_ns':pulse,'latency_ms':(pulse-t)/1e6,'event':e})
out={'method':'For each PIR rising edge, find RESPONSE rises in the following 200ms. Require exactly one pulse that matches a nearby_motion UART event time_ms within 20ms and has no other event time_ms within 20ms. Other RESPONSE pulses in the interval are allowed when tied to different events. MCU time and VCD timestamps are compared directly; no physical timing claim.','pir_rises':len(pirs),'qualified_pairs':len(pairs),'distinct_event_sequences':len({x['event']['seq'] for x in pairs}),'min_ms':min(x['latency_ms'] for x in pairs) if pairs else None,'max_ms':max(x['latency_ms'] for x in pairs) if pairs else None,'pairs':pairs,'vcd_sha256':hashlib.sha256(Path('s3.vcd').read_bytes()).hexdigest()}
Path('s3-correlated-pairs.json').write_text(json.dumps(out,indent=2)+'\n'); print({k:v for k,v in out.items() if k!='pairs'})
