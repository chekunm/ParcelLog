#include "wokwi-api.h"
typedef struct { pin_t analog, pir; timer_t timer; unsigned phase; } State;
static State s;
static void step(void *p) {
 State *q=p; ++q->phase;
 switch(q->phase) {
  case 1: pin_dac_write(q->analog, 0.0f); break;
  case 2: pin_dac_write(q->analog, 3.3f); break;
  case 3: pin_dac_write(q->analog, 1.65f); break;
  case 4: pin_write(q->pir, HIGH); timer_start(q->timer, 200000, false); return;
  case 5: pin_write(q->pir, LOW); return;
 }
 timer_start(q->timer, 5000000, false);
}
void chip_init(void) {
 s.analog=pin_init("LIGHT", ANALOG); s.pir=pin_init("PIR", OUTPUT_LOW);
 pin_dac_write(s.analog,1.65f);
 const timer_config_t c={.user_data=&s,.callback=step};s.timer=timer_init(&c);
 timer_start(s.timer,5000000,false);
}
