from pathlib import Path
import hashlib,json,statistics,sys
p=Path(sys.argv[1]);edge={k:[] for k in ['!','"','$','&',"'",'(']};last={};now=0;first=None
for line in p.open():
 x=line.strip()
 if x.startswith('#'):
  now=int(x[1:]);first=now if first is None else first
 elif len(x)==2 and x[0] in '01' and x[1] in edge:
  if last.get(x[1])!=x[0]:edge[x[1]].append([now,int(x[0])])
  last[x[1]]=x[0]
# Separate rise/fall arrays to keep this reviewable and avoid treating startup as pulse.
samples=[t for t,v in edge['!'] if v];sample_intervals=[(b-a)/1e6 for a,b in zip(samples,samples[1:])]
pir=[t for t,v in edge['$'] if v];resp=[t for t,v in edge['&'] if v];flash=edge['"'];active=False;f_intervals=[];on=None
for t,v in flash:
 if v: on=t
 elif on is not None:f_intervals.append((on,t));on=None
inflash=[t for t in pir if any(a<=t<b for a,b in f_intervals)]
out={'vcd_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'first_ns':first,'end_ns':now,'sample_rises':len(samples),'sample_first_ns':samples[0] if samples else None,'sample_last_ns':samples[-1] if samples else None,'sample_period_ms':{'min':min(sample_intervals) if sample_intervals else None,'median':statistics.median(sample_intervals) if sample_intervals else None,'max':max(sample_intervals) if sample_intervals else None},'pir_rises':len(pir),'flash_pulses':len(f_intervals),'pir_inside_flash':len(inflash),'response_rises':len(resp)}
Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
