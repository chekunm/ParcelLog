from pathlib import Path
import datetime,json,os,re,signal,time
import serial
p=Path(__file__).resolve().parent
state={'pid':os.getpid(),'state':'waiting','port':4524,'required_mcu_ms':3600000,'commands':[],'resets':0,'uart_bytes':0,'notes':'FF-initialized simulated internal flash; no erase; 30 marks and PIR pulse every 60s'}
def save():
 tmp=p/'collector.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(p/'collector.json')
stop=False
def sig(*_):
 global stop
 stop=True
signal.signal(signal.SIGTERM,sig);signal.signal(signal.SIGINT,sig)
state['start_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
end=time.monotonic()+600
while not stop and time.monotonic()<end:
 try:c=serial.serial_for_url('rfc2217://127.0.0.1:4524',baudrate=115200,timeout=.1);break
 except (OSError,serial.SerialException):time.sleep(.25)
else:state['state']='connection_timeout';save();raise SystemExit(1)
state['state']='recording';save();first=last=None;buf=bytearray();next_mark=60000;next_stats=5000;sent_initial_log=False;final_start=None;last_save=time.monotonic();last_tick_wall=time.monotonic()
def send(cmd,now):
 b=(cmd+'\n').encode();n=c.write(b);state['commands'].append({'command':cmd,'mcu_ms':now,'bytes':n,'wall_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 if n!=len(b):raise IOError('short UART write')
try:
 with c,(p/'uart.raw').open('wb') as out:
  while not stop:
   data=c.read(c.in_waiting or 1)
   if data:
    out.write(data);out.flush();state['uart_bytes']+=len(data);buf.extend(data)
    while b'\n' in buf:
     line,_,rest=buf.partition(b'\n');buf=bytearray(rest)
     m=re.search(rb'tick \[(\d+) ms\]',line)
     if not m:continue
     now=int(m.group(1));last_tick_wall=time.monotonic()
     if first is None:first=now;state['first_tick_ms']=now
     if last is not None and now<=last:
      state['resets']+=1;raise RuntimeError(f'MCU tick nonmonotonic: {last} -> {now}')
     last=now;state['last_tick_ms']=now;elapsed=now-first;state['continuous_mcu_ms']=elapsed
     if not sent_initial_log and elapsed>=10000:send('log',now);sent_initial_log=True
     if next_mark<=3540000 and elapsed>=next_mark:send('mark',now);next_mark+=120000
     if elapsed>=next_stats and next_stats<=2705000:send('stats',now);next_stats+=900000
     if elapsed>=3605000 and final_start is None:
      send('stats',now);send('log',now);final_start=now;state['final_requested_ms']=now
     if final_start is not None and now-final_start>=20000:state['state']='complete';break
    if state['state']=='complete':break
   if time.monotonic()-last_save>=10:
    state['tick_silence_wall_s']=round(time.monotonic()-last_tick_wall,1);save();last_save=time.monotonic()
 if stop:state['state']='interrupted'
except Exception as e:state.update(state='failed',error=repr(e))
finally:state['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
