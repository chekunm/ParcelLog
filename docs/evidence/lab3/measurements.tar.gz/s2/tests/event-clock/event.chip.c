#include "wokwi-api.h"
typedef struct { pin_t pir; timer_t timer; int high; } State;
static State state;
static void tick(void *p) { State *s=p; s->high=!s->high; pin_write(s->pir,s->high ? HIGH : LOW); timer_start(s->timer,s->high ? 200000 : 59800000,false); }
void chip_init(void) { state.pir=pin_init("PIR",OUTPUT_LOW); const timer_config_t cfg={.user_data=&state,.callback=tick}; state.timer=timer_init(&cfg); timer_start(state.timer,10000000,false); }
