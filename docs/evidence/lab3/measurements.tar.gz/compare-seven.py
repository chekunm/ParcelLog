from pathlib import Path
from collections import defaultdict, Counter
from itertools import combinations
from datetime import datetime
from zoneinfo import ZoneInfo
import ast, difflib, hashlib, json, re, subprocess, os, shutil

STUDY=Path('/Users/pliffdax/Projects/university/Study')
OUT=Path('/Users/pliffdax/Projects/university/Study/People/Чекун Микола Олексійович/2026-Fall/SP/Lab03/Work/final-20261103/similarity-check')
OUT.mkdir(parents=True,exist_ok=False)
SPECS=[('SpinWatch','Голуб Денис Дмитрович','ToolSafe'),('BalanceGame','Бурлій Андрій Євгенійович','ExpoGuard'),('LightBench','Пашко Максим Ігорович','ShelfWatch'),('LabWatch','Добрановський Станіслав Вадимович','LabWatch'),('ParcelLog','Чекун Микола Олексійович','ParcelLog'),('SunAlign','Мойса Анастасія Святославівна','SunAlign'),('DrawerLog','Логовський Роман Ігорович','DrawerLog')]
PROJECTS={n:dict(owner=o,repo=STUDY/'People'/o/'2026-Fall/SP/Lab01/Work'/r,base=STUDY/'People'/o/'2026-Fall/SP') for n,o,r in SPECS}
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,obj):(OUT/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
LEX=re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|0[xX][0-9a-fA-F]+[uUlL]*|\d+(?:\.\d+)?[uUlLfF]*|\S')
KEY=set('if else while for do return break continue switch case default sizeof static const volatile void unsigned signed int char short long float double struct enum union typedef bool true false NULL inline uint8_t uint16_t uint32_t uint64_t int8_t int16_t int32_t int64_t size_t'.split())
def toks(s):return [m.group() for m in LEX.finditer(s) if not m.group().startswith(('//','/*'))]
def norm(ts):
 names={};out=[]
 for t in ts:
  if re.fullmatch(r'[A-Za-z_]\w*',t) and t not in KEY:
   if t not in names:names[t]='v'+str(len(names))
   out.append(names[t])
  else:out.append(t)
 return out
def fns(s,ext):
 out=[]
 if ext=='.py':
  try:
   tree=ast.parse(s)
   lines=s.splitlines(keepends=True)
   for n in ast.walk(tree):
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
     body=''.join(lines[n.lineno-1:n.end_lineno]);out.append((n.name,n.lineno,n.end_lineno,body))
  except (SyntaxError,ValueError):pass
 else:
  # Replace comments/strings with equal-length whitespace, preserving line positions.
  mask=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()),s)
  for m in re.finditer(r'\b([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{',mask):
   name=m.group(1)
   if name in KEY:continue
   brace=mask.find('{',m.start());depth=1;k=brace+1
   while k<len(mask) and depth:
    depth+=(mask[k]=='{')-(mask[k]=='}');k+=1
   if depth==0:
    out.append((name,s.count('\n',0,m.start())+1,s.count('\n',0,k)+1,s[brace:k]))
 return out
def shingles(t,n):return set(zip(*(t[i:] for i in range(n)))) if len(t)>=n else set()

files=[];functions=[];manifest=[]
for name,d in PROJECTS.items():
 repo=d['repo'];status=subprocess.check_output(['git','-C',str(repo),'status','--porcelain=v1'],text=True)
 info=dict(project=name,owner=d['owner'],repo=str(repo),head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),status=status,files=[])
 candidates=[]
 for folder in ['firmware/App','firmware/Platform','firmware/Devices','tests','tools','sim']:
  q=repo/folder
  if not q.exists():continue
  for root,dirs,names in os.walk(q):
   dirs[:]=[x for x in dirs if x not in ['build','__pycache__','node_modules','.git'] and not x.startswith('build-')]
   for n in names:
    p=Path(root)/n
    if p.suffix in ('.c','.h','.py','.mjs','.js') and p.stat().st_size<500000:candidates.append(p)
 for p in sorted(set(candidates)):
  raw=p.read_bytes();s=raw.decode(errors='replace');rel=str(p.relative_to(repo));ts=toks(s);nt=norm(ts)
  snap=OUT/'snapshot'/name/rel;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(raw)
  cat='product' if rel.startswith('firmware/App/') else 'driver' if rel.startswith('firmware/Devices/') else 'platform' if rel.startswith('firmware/Platform/') else rel.split('/')[0]
  f=dict(project=name,path=rel,absolute=str(p),category=cat,sha256=sha(raw),token_sha256=sha(' '.join(ts).encode()),normalized_sha256=sha(' '.join(nt).encode()),tokens=len(ts),lines=len(s.splitlines()))
  info['files'].append(f);files.append({**f,'ts':ts,'nt':nt})
  for fn,lo,hi,body in fns(s,p.suffix):
   tsf=toks(body);nf=norm(tsf)
   if len(nf)>=50:
    functions.append(dict(project=name,path=rel,name=fn,start=lo,end=hi,category=cat,tokens=len(nf),ts=tsf,nt=nf,grams=shingles(nf,7)))
 for rel in ['README.md','docs/PRD.md','docs/architecture.md','docs/boilerplate-readme.md','docs/boilerplate-README.md','docs/lab3-report.md','docs/limitations.md']:
  p=repo/rel
  if p.exists():
   snap=OUT/'snapshot'/name/rel;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 manifest.append(info)
save('manifest.json',dict(recorded_at=datetime.now(ZoneInfo('Europe/Kyiv')).isoformat(),projects=manifest,exclusions=['HAL/CMSIS/Drivers, generated Core/startup, build products, virtual environments; these are not counted as authored application code'],scope='current filesystem including dirty/untracked authored sources; snapshot SHA256 pins each file'))
print('OUT',OUT,flush=True);print('FILES',len(files),'FUNCTIONS',len(functions),flush=True)

exact=[];filepairs=[];fnmatches=[]
for a,b in combinations(PROJECTS,2):
 fa=[f for f in files if f['project']==a];fb=[f for f in files if f['project']==b]
 for x in fa:
  gx=shingles(x['nt'],20)
  for y in fb:
   if x['tokens']<80 or y['tokens']<80:continue
   eq=[k for k in ['sha256','token_sha256','normalized_sha256'] if x[k]==y[k]]
   if eq:exact.append(dict(a=a,b=b,path_a=x['path'],path_b=y['path'],tokens_a=x['tokens'],tokens_b=y['tokens'],equal_by=eq))
   if x['category']!=y['category']:continue
   gy=shingles(y['nt'],20);common=len(gx&gy);contain=common/max(1,min(len(gx),len(gy)))
   if common>=8 and contain>=.2:filepairs.append(dict(a=a,b=b,path_a=x['path'],path_b=y['path'],category=x['category'],shared_unique_20grams=common,smaller_shingle_containment=round(contain,4)))
 inv=defaultdict(set)
 fnb=[f for f in functions if f['project']==b]
 for j,y in enumerate(fnb):
  for g in y['grams']:inv[g].add(j)
 for x in [f for f in functions if f['project']==a]:
  hits=Counter(j for g in x['grams'] for j in inv.get(g,()))
  for j,common in hits.items():
   y=fnb[j]
   if common<5 or common/max(1,min(len(x['grams']),len(y['grams'])))<.2:continue
   sm=difflib.SequenceMatcher(None,x['nt'],y['nt'],autojunk=False);ratio=sm.ratio();longest=max(sm.get_matching_blocks(),key=lambda q:q.size)
   if ratio<.72 and longest.size<90:continue
   fnmatches.append(dict(a=a,b=b,path_a=x['path'],path_b=y['path'],name_a=x['name'],name_b=y['name'],line_a=x['start'],end_a=x['end'],line_b=y['start'],end_b=y['end'],category_a=x['category'],category_b=y['category'],tokens_a=x['tokens'],tokens_b=y['tokens'],normalized_ratio=round(ratio,4),longest_normalized_token_block=longest.size,exact_tokens=x['ts']==y['ts'],normalized_equal=x['nt']==y['nt']))
 print('PAIR',a,b,'matches',sum(x['a']==a and x['b']==b for x in fnmatches),flush=True)
save('exact-files.json',exact);save('file-candidates.json',sorted(filepairs,key=lambda x:-x['smaller_shingle_containment']));save('function-candidates.json',sorted(fnmatches,key=lambda x:(-x['normalized_ratio'],-x['longest_normalized_token_block'])))
save('candidate-summary.json',[dict(a=a,b=b,exact_files=[x for x in exact if x['a']==a and x['b']==b],top_functions=sorted([x for x in fnmatches if x['a']==a and x['b']==b],key=lambda x:(-x['normalized_ratio'],-x['longest_normalized_token_block']))[:25]) for a,b in combinations(PROJECTS,2)])
shutil.copy2(__file__,OUT/'audit.py')
print('DONE',OUT,flush=True)
