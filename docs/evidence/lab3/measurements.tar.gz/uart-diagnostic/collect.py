from pathlib import Path
import os,signal,time,json,sys
import serial
p=Path(__file__).resolve().parent; state={'state':'waiting','pid':os.getpid(),'port':4525};(p/'collector.json').write_text(json.dumps(state))
end=time.monotonic()+180
while time.monotonic()<end:
 try:c=serial.serial_for_url('rfc2217://127.0.0.1:4525',baudrate=115200,timeout=.1);break
 except (OSError,serial.SerialException):time.sleep(.2)
else:state['state']='connection_timeout';(p/'collector.json').write_text(json.dumps(state));sys.exit(1)
schedule=json.loads((p/'schedule.json').read_text());start=None;state['state']='recording';sent=[];count=0
try:
 with c,(p/'uart.raw').open('wb') as out:
  while start is None:
   chunk=c.read(c.in_waiting or 1)
   if chunk:
    out.write(chunk);out.flush();count+=len(chunk);start=time.monotonic()
  while time.monotonic()-start<165:
   elapsed=time.monotonic()-start
   while schedule and elapsed>=schedule[0]['after_seconds']:
    x=schedule.pop(0); data=(x['text']+'\n').encode();sent.append({'host_s':elapsed,'command':x['text'],'bytes_written':c.write(data)})
   chunk=c.read(c.in_waiting or 1)
   if chunk:out.write(chunk);out.flush();count+=len(chunk)
 state['state']='complete'
except Exception as e:state.update(state='failed',error=repr(e))
finally:
 state.update(duration_s=time.monotonic()-start,bytes=count,commands=sent);(p/'collector.json').write_text(json.dumps(state,indent=2)+'\n')
