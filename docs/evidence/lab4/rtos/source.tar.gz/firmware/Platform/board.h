#ifndef PROJECT_BOARD_H
#define PROJECT_BOARD_H
#include "mpu6050.h"
#include "shipment_log.h"
#include <stdbool.h>
#include <stdint.h>
void board_init(void);
SensorBus board_sensor_bus(void);
bool board_read_light(uint16_t *value);
bool board_motion(void);
bool board_storage(void);
void board_led(bool on);
int board_get_char(void);
bool board_rx_overflow(void);
int board_put_char(int value);
bool board_tx_overflow(void);
ShipmentStorage board_shipment_storage(void);
unsigned board_tx_free(void);
uint32_t board_rx_timestamp(void);
uint32_t board_motion_timestamp(void);
#endif
