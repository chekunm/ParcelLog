#ifndef BUILD_VERSION_H
#define BUILD_VERSION_H
#define BUILD_GIT "57be81df4580+lab3-worktree"
#define BUILD_SOURCE "af74d9d748fe5d1d"
#endif
