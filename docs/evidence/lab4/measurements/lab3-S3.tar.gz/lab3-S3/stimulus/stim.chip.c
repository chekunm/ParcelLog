#include "wokwi-api.h"
#include <string.h>
#include <stdlib.h>
static uart_dev_t uart;
static pin_t pir, flash, mode, light, sda_fault;
static unsigned scenario, step, phase;
static timer_t pulse_timer, delay_timer;
static uint8_t tx[200];
static uint8_t registers[128], cursor;
static bool expect_cursor;
static uint32_t random_state=0x50434c34u;
static uint32_t random_delay(void) {random_state=random_state*1664525u+1013904223u;return 100u+random_state%1000u;}
static char response_line[512];
static unsigned response_size, boundary_sent, boundary_credit;
static bool boundary_failed, boundary_stopped, boundary_stats_sent;
static unsigned field(const char *line,const char *key) {
    const char *p=strstr(line,key);return p ? (unsigned)strtoul(p+strlen(key),NULL,10) : 0;
}
static void receive(void *arg,uint8_t byte) {
    (void)arg;
    if (scenario!=5) return;
    if (byte=='\n') {
        response_line[response_size]=0;
        if ((strstr(response_line,"STAT task=command_latency ") && field(response_line,"max_us=")>20000) ||
            (strstr(response_line,"STAT task=sample ") && (field(response_line,"skipped=") || field(response_line,"deadline_miss="))) ||
            field(response_line,"rx_overflows=") || field(response_line,"tx_overflow=")) boundary_failed=true;
        if (boundary_failed && boundary_sent>=30) {boundary_stopped=true;pin_write(mode,LOW);}
        response_size=0;
    } else if (response_size<sizeof response_line-1) response_line[response_size++]=(char)byte;
}
static bool connect_device(void *context,uint32_t address,bool read) {
    (void)context;(void)address;
    if (scenario==4 && step<30) return false; /* connected but not ready for 3 s */
    if (!read) expect_cursor=true;return true;
}
static bool write_byte(void *context,uint8_t value) {
    (void)context;
    if (expect_cursor) {cursor=value&127u;expect_cursor=false;}
    else {registers[cursor]=value;cursor=(cursor+1u)&127u;}
    return true;
}
static uint8_t read_byte(void *context) { (void)context;uint8_t value=registers[cursor];cursor=(cursor+1u)&127u;return value; }
static void axis(unsigned offset,int16_t value) {registers[offset]=(uint16_t)value>>8;registers[offset+1]=(uint8_t)value;}
static void send(const char *text) {
    unsigned n=(unsigned)strlen(text);memcpy(tx,text,n);uart_write(uart,tx,n);
}
static void pulse_end(void *arg) { (void)arg;pin_write(pir,LOW);phase=0; }
static void short_start(void *arg) {
    (void)arg;pin_write(pir,HIGH);timer_start(pulse_timer,20000,false);
}
static void pulse_start(void *arg) {
    (void)arg;
    if (pin_read(flash)==HIGH) {
        pin_write(pir,HIGH);phase=2;timer_start(pulse_timer,200000,false);
    } else phase=0;
}
static void flash_changed(void *arg,pin_t pin,uint32_t value) {
    (void)arg;(void)pin;
    if (scenario==3 && value==HIGH && phase==0) {
        phase=1;timer_start(delay_timer,random_delay(),false);
    }
}
static void timer(void *arg) {
    (void)arg;++step;
    if (scenario==3) {
        if (step<3100) {
            if (step%100==10) send("trace\nmark\nlog\n");
            else if (step%100==40) send("erase CONFIRM\n");
            else send("status\n");
        } else if (step==3110) send("stats\n");
        else if (step==3120) send("tasks\n");
        else if (step==3130) send("log\n");
    } else if (scenario==2) {
        unsigned within=step%600;
        pin_write(pir,within==550 || within==551 ? HIGH : LOW);
    } else if (scenario==4) {
        /* 30 short pulses, then >=150ms pulses. Mode starts transit, storage
         * entry with already high is explicitly included at 10 seconds. */
        if (step==95) pin_write(pir,HIGH);
        if (step==100) pin_write(mode,HIGH);
        if (step==105) pin_write(pir,LOW);
        if (step>150 && step<750) {
            if (step%20==0) timer_start(delay_timer,((step/20u)*37u%90u)*1000u+1u,false);
        } else if (step>=800 && step<1400) {
            pin_write(pir,step%20<2 ? HIGH : LOW);
        }
        if (step==1500) pin_write(mode,LOW);
        if (step==1700) pin_write(mode,HIGH);
        if (step==1530 || step==1540) {pin_write(pir,HIGH);timer_start(pulse_timer,200000,false);}
        unsigned state=(step/10u)%4u;
        axis(0x3b,state==2 ? 11469 : 0);axis(0x3d,0);axis(0x3f,state==1 ? 29491 : state==2 ? 11469 : 16384);
        unsigned illumination=(step/20u)%4u;
        pin_dac_write(light,illumination==1 ? 0.0f : illumination==3 ? 3.3f : 1.65f);
        if (step%50==30 && step<3000) send("mark\nlog\n");
        if (step==2000) send("imuaddr 0x69\n");
        if (step==2100) send("imuaddr 0x68\n");
        if (step==2300) pin_mode(sda_fault,OUTPUT_LOW);
        if (step==2330) pin_mode(sda_fault,INPUT);
        if (step==3110) send("stats\n");
        if (step==3120) send("tasks\n");
        if (step==3130) send("log\n");
    } else if (scenario==5) {
        const unsigned rates[]={1,5,10,25,50,100,200};
        if (step>=5000) {
            unsigned stage=(step-5000)/50000,within=(step-5000)%50000;
            if (within==0) {boundary_sent=boundary_credit=0;boundary_stats_sent=false;}
            if (stage<7 && within<40000 && !boundary_stopped) {
                boundary_credit+=rates[stage];
                if (boundary_credit>=1000) {send("status\n");boundary_credit-=1000;++boundary_sent;}
                if (boundary_failed && boundary_sent>=30) {boundary_stopped=true;pin_write(mode,LOW);}
            }
            if (((stage<7 && within==40000) || boundary_stopped) && !boundary_stats_sent) {
                send("stats\n");boundary_stats_sent=true;
            }
            if (stage>=7 && !boundary_stopped) {boundary_stopped=true;pin_write(mode,LOW);send("stats\n");}
        }
    } else if (scenario==6) {
        pin_write(pir,step>=100 && step%100<2 ? HIGH : LOW);
        if (step%100==30 && step<3000) send("mark\n");
        if (step==10 || step==3110) send("stats\n");
        if (step==20 || step==3130) send("log\n");
        if (step==3120) send("tasks\n");
    }
}
void chip_init(void) {
    scenario=attr_read(attr_init("scenario",1));
    pir=pin_init("PIR",OUTPUT_LOW);flash=pin_init("FLASH",INPUT);
    mode=pin_init("MODE",scenario==4 ? OUTPUT_LOW : OUTPUT_HIGH);
    light=pin_init("LIGHT",ANALOG);pin_dac_write(light,1.65f);
    sda_fault=pin_init("SDA_FAULT",INPUT);
    uart_config_t u={.tx=pin_init("TX",OUTPUT_HIGH),.rx=pin_init("UNUSED_RX",INPUT),.baud_rate=115200,.rx_data=receive};
    uart=uart_init(&u);
    if (scenario==4) {
        registers[0x75]=0x68;axis(0x3f,16384);
        i2c_config_t bus={.address=0x68,.scl=pin_init("SCL",INPUT),.sda=pin_init("SDA",INPUT),
            .connect=connect_device,.read=read_byte,.write=write_byte};
        i2c_init(&bus);
    }
    timer_config_t t={.callback=timer};timer_t periodic=timer_init(&t);timer_start(periodic,scenario==5 ? 1000 : 100000,true);
    timer_config_t pulse={.callback=pulse_end};pulse_timer=timer_init(&pulse);
    pulse.callback=scenario==4 ? short_start : pulse_start;delay_timer=timer_init(&pulse);
    pin_watch_config_t watch={.edge=RISING,.pin_change=flash_changed};pin_watch(flash,&watch);
}
